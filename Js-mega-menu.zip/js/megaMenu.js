//grab all the links in menu items.
var menuItems = document.querySelectorAll(".menu-item>a");

function displayInfoPanel(event){
  	var anchor = event.target;
 	var infoPanel =anchor.parentNode.querySelector(".menu-item-info");
//make panel visble
  infoPanel.classList.add("is-visible");
}
function hideInfo(event){
  var anchor = event.target;
 var infoPanel =anchor.parentNode.querySelector(".menu-item-info");
//make panel visble
  infoPanel.classList.remove("is-visible");
}
//iterate over list and register callback on mouse over
for (var i=0; i<menuItems.length; i++){
  //we have each anchor in menu
  //register a call back on mouse over
  var anchor=menuItems[i];
  anchor.addEventListener("mouseover",displayInfoPanel);
  anchor.addEventListener("mouseout",hideInfo);
}